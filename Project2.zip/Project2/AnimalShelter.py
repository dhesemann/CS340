from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:38012/AAC' % (username, password))
        self.database = self.client['AAC']

# Create function
    def create(self, data):
        if data is not None:
            insert = self.database.animals.insert(data)  # data should be dictionary        
            if insert != False:
                return True
            else:
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False

# Read function 
    def read(self, lookup):
        if lookup != False:
            # Return results
            data = self.database.animals.find(lookup,{"_id":False})
            return data
        else:
            raise Exception("No results found")
            
# Update function
    def update(self, lookup, newDoc):
        if lookup != False:
            # Find the document
            # Account for similar entries
            docList = self.database.animals.find(lookup)
            if docList.count() > 1:
                raise Exception("Multiple documents exist with the given criteria")
            else:
                # Update/change the document
                updateResult = self.database.animals.update(lookup, newDoc)
                # Return result
                return updateResult
        else:
            raise Exception("Document does not exist")
            
# Delete function
    def delete(self, lookup):
        if lookup != False:
            # Find and the document
            # Account for duplicate entries
            docList = self.database.animals.find(lookup)
            if docList.count() > 1:
                raise Exception("Multiple documents exist with the given criteria")
            else:
                # Delete the document
                deleteResult = self.database.animals.remove(lookup)
                # Return result
                return deleteResult
        else:
            raise Exception("Document does not exist")
            
            